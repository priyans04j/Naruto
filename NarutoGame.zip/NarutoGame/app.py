from flask import Flask, render_template, request, redirect, url_for, session
import random
from playsound import playsound

app = Flask(__name__)
app.secret_key = 'naruto-secret-key'

# Character setup
characters = {
    'naruto': {
        'name': 'Naruto Uzumaki',
        'health': 100,
        'chakra': 100,
        'level': 1,
        'experience': 0,
        'jutsus': {
            'Rasengan': {'power': 25, 'chakra_cost': 20},
            'Shadow Clone': {'power': 15, 'chakra_cost': 10},
            'Sage Mode': {'power': 40, 'chakra_cost': 40},
            'Nine-Tails Cloak': {'power': 50, 'chakra_cost': 50, 'special': 'Regenerates 20 health'}
        }
    },
    'sakura': {
        'name': 'Sakura Haruno',
        'health': 90,
        'chakra': 100,
        'level': 1,
        'experience': 0,
        'jutsus': {
            'Cherry Blossom Impact': {'power': 30, 'chakra_cost': 25},
            'Healing Jutsu': {'power': 0, 'chakra_cost': 15, 'special': 'Restores 20 health'},
            'Inner Sakura': {'power': 20, 'chakra_cost': 10}
        }
    },
    'rock_lee': {
        'name': 'Rock Lee',
        'health': 110,
        'chakra': 80,
        'level': 1,
        'experience': 0,
        'jutsus': {
            'Primary Lotus': {'power': 35, 'chakra_cost': 30},
            'Leaf Whirlwind': {'power': 20, 'chakra_cost': 15},
            'Drunken Fist': {'power': 25, 'chakra_cost': 25}
        }
    },
    'jiraiya': {
        'name': 'Jiraiya',
        'health': 120,
        'chakra': 150,
        'level': 1,
        'experience': 0,
        'jutsus': {
            'Rasenshuriken': {'power': 40, 'chakra_cost': 35},
            'Toad Summoning': {'power': 50, 'chakra_cost': 50},
            'Sage Mode': {'power': 45, 'chakra_cost': 40}
        }
    },
}

# Inventory and items
items = {
    'health_potion': {'name': 'Health Potion', 'heal_amount': 20},
    'chakra_potion': {'name': 'Chakra Potion', 'restore_amount': 30}
}

# Story arcs
story_arcs = {
    'land_of_waves': {
        'name': 'Land of Waves Arc',
        'battles': ['zabuza', 'haku']
    },
}

def level_up(character):
    character['level'] += 1
    character['health'] += 10
    character['chakra'] += 10

def grant_experience(player, enemy):
    exp_gain = 20
    player['experience'] += exp_gain
    if player['experience'] >= 100:
        level_up(player)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/story')
def story():
    return render_template('story.html', arcs=story_arcs)

@app.route('/start_battle/<arc>')
def start_battle(arc):
    session['arc'] = arc
    session['player'] = characters['naruto']
    session['player']['inventory'] = []
    session['enemy'] = {
        'name': 'Zabuza Momochi',
        'health': 100,
        'chakra': 100,
        'jutsus': {
            'Water Dragon Jutsu': {'power': 30, 'chakra_cost': 25},
            'Mist Jutsu': {'power': 0, 'chakra_cost': 10}
        }
    }
    return render_template('battle.html', player=session['player'], enemy=session['enemy'], arc=arc)

@app.route('/battle', methods=['POST'])
def battle():
    player_jutsu = request.form['jutsu']
    player = session['player']
    enemy = session['enemy']
    
    player_damage = player['jutsus'][player_jutsu]['power']
    player_chakra_cost = player['jutsus'][player_jutsu]['chakra_cost']
    
    if player['chakra'] < player_chakra_cost:
        return render_template('result.html', result="Not enough chakra!")

    player['chakra'] -= player_chakra_cost
    enemy['health'] -= player_damage

    if enemy['health'] <= 0:
        grant_experience(player, enemy)
        result = f"{enemy['name']} is defeated! Naruto wins!"
        return render_template('result.html', result=result)

    enemy_jutsu = random.choice(list(enemy['jutsus'].keys()))
    enemy_damage = enemy['jutsus'][enemy_jutsu]['power']
    enemy_chakra_cost = enemy['jutsus'][enemy_jutsu]['chakra_cost']

    if enemy['chakra'] < enemy_chakra_cost:
        return render_template('result.html', result=f"{enemy['name']} is too exhausted to attack!")

    enemy['chakra'] -= enemy_chakra_cost
    player['health'] -= enemy_damage

    if player['health'] <= 0:
        return render_template('result.html', result="Naruto is defeated!")

    session['player'] = player
    session['enemy'] = enemy

    return render_template('battle.html', player=player, enemy=enemy, arc=session['arc'])

@app.route('/result', methods=['GET', 'POST'])
def result():
    if request.method == 'POST':
        arc = session['arc']
        next_battle_index = story_arcs[arc]['battles'].index(session['enemy']['name']) + 1
        
        if next_battle_index < len(story_arcs[arc]['battles']):
            next_enemy = characters[story_arcs[arc]['battles'][next_battle_index]]
            session['enemy'] = next_enemy
            return render_template('battle.html', player=session['player'], enemy=next_enemy, arc=arc)
        else:
            return render_template('result.html', result="Congratulations! You've completed the arc!")
    
    return redirect(url_for('home'))

@app.route('/collect_item', methods=['POST'])
def collect_item():
    item_name = request.form['item']
    if item_name in items:
        session['player']['inventory'].append(item_name)
    return redirect(url_for('battle'))

if __name__ == '__main__':
    app.run(debug=True)